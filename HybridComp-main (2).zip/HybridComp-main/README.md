# Hybrid Comprehensive Assessment

Clone the repo and use `mvn test` to run the project
